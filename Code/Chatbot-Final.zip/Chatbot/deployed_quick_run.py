import json
import uuid
import sys
from pathlib import Path

import vertexai
from google.cloud import aiplatform

# --- Add src directory to Python path ---
current_dir = Path(__file__).parent
src_dir = current_dir / "src"
sys.path.insert(0, str(src_dir))

# Now we can import directly from src files
from config import PROJECT_ID, REGION
from agent_engine import setup_vertex_agent_engine
from vertex_vector_search import VertexVectorSearch
from rag_engine import VertexRAGEngine


def attach_existing_vector_search():
    """Attach to existing index/endpoint strictly by display name (no creation)."""
    vvs = VertexVectorSearch()
    vvs.index = vvs.get_or_create_index(gcs_uri=None)
    vvs.endpoint = vvs.get_or_create_endpoint()
    if not vvs.index or not vvs.endpoint:
        print("Vector Search index or endpoint not found. Skipping Vector Search.")
        return None
    if not vvs.ensure_deployed():
        print("Vector Search deployment missing. Skipping Vector Search.")
        return None
    vvs.load_document_metadata()
    return vvs


def attach_existing_rag():
    """Attach to existing RAG corpus by display name."""
    try:
        rag_engine = VertexRAGEngine()
        if not rag_engine.get_or_create_corpus():
            print("RAG corpus not found. Skipping RAG.")
            return None
        if not rag_engine.create_generative_model():
            print("RAG generative model could not be initialized. Skipping RAG.")
            return None
        return rag_engine
    except Exception as e:
        print(f"RAG attach failed: {e}")
        return None


def main():
    print("Quick Run — HDFC Life Insurance Assistant")
    print(f"Project: {PROJECT_ID} | Region: {REGION}")

    vertexai.init(project=PROJECT_ID, location=REGION)
    aiplatform.init(project=PROJECT_ID, location=REGION)

    info_path = Path("deployment_info.json")
    if info_path.exists():
        try:
            info = json.loads(info_path.read_text())
            print(f"Last deployment: {info.get('deployment_name')} at {info.get('timestamp')}")
        except Exception:
            pass

    vvs = attach_existing_vector_search()
    rag_engine = attach_existing_rag()

    if not (vvs or rag_engine):
        print("No existing RAG or Vector Search resources found.")
        print("Run 'python vertex_cloud_main.py' once to provision resources.")
        return

    agent = setup_vertex_agent_engine(rag_engine=rag_engine, vector_search=vvs)
    if not agent:
        print("Could not initialize agent engine.")
        return

    print("Assistant is ready. Type your questions; 'exit' to quit.")
    session_id = str(uuid.uuid4())
    while True:
        q = input("\nYour question: ").strip()
        if q.lower() == "exit":
            print("Goodbye. Have a nice day!!!")
            break
        if not q:
            continue
        ans = agent.generate_agent_response(q, session_id)
        print(f"\nAnswer: {ans}")


if __name__ == "__main__":
    main()
