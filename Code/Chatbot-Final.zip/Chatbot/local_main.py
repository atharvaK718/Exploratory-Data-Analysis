import os
import sys
import uuid
from pathlib import Path

current_dir = Path(__file__).parent
src_dir = current_dir / "src"
sys.path.insert(0, str(src_dir))

import src.config as config
from src.vector_store import setup_vector_store
from src.vertex_agent import setup_agent, talk_to_agent


def check_prerequisites():
    """Check if all prerequisites are met."""
    issues = []
    if config.PROJECT_ID == "your-gcp-project-id":
        issues.append("Update your GCP Project ID in src/config.py")

    data_dir = Path("data")
    if not data_dir.exists():
        data_dir.mkdir(exist_ok=True)
        issues.append("Created data/ directory. Add PDF/TXT files to it.")
    elif not any(data_dir.glob("*.pdf")) and not any(data_dir.glob("*.txt")):
        issues.append("No PDF or TXT files found in data/ directory. Add documents.")

    try:
        import google.auth
        credentials, project = google.auth.default()
        if not project:
            issues.append("Google Cloud credentials not found. Run 'gcloud auth application-default login'")
    except Exception:
        issues.append("Google Cloud authentication issue. Run 'gcloud auth application-default login'")
    return issues


def main():
    print("Starting Insurance Assistant ")
    print(f"Using Project: {config.PROJECT_ID}")

    issues = check_prerequisites()
    if issues:
        print("\nSetup issues found:")
        for issue in issues:
            print(f" - {issue}")
        print("\nSetup checklist:")
        print("1. Update PROJECT_ID in src/config.py")
        print("2. Run: gcloud auth application-default login")
        print("3. Enable Vertex AI API: gcloud services enable aiplatform.googleapis.com")
        print("4. Add PDF/TXT documents to the data/ folder")
        return
    try:
        print("=" * 60)
        vector_store = setup_vector_store()
        if not vector_store:
            print("Failed to set up vector store. Check configuration.")
            return
        agent = setup_agent(vector_store)
        if not agent:
            print("Failed to set up agent. Check configuration.")
            return
        print("=" * 60)
        print("HDFC LIFE INSURANCE ASSISTANT")
        print("=" * 60)
        print("Ask your questions. ")
        print("Type 'exit' to quit, 'help' for more options.")
        print("=" * 60)

        session_id = str(uuid.uuid4())
        print(f"Session ID: {session_id[:8]}...")

        data_dir = Path("data")
        pdf_files = list(data_dir.glob("*.pdf"))
        if pdf_files:
            print(f"\nLoaded {len(pdf_files)} insurance documents:")
            for i, file in enumerate(pdf_files[:3], 1):
                print(f"  {i}. {file.name}")
            if len(pdf_files) > 3:
                print(f"  ... and {len(pdf_files) - 3} more documents")


        while True:
            try:
                query = input("\nYour question: ").strip()
                if query.lower() == 'exit':
                    print("Thank you for using HDFC Life Insurance Assistant.")
                    break
                elif query.lower() == 'help':
                    print_help()
                    continue
                elif query.lower() == 'status':
                    print_status(vector_store)
                    continue
                elif not query:
                    continue
                print("\nAnalyzing your insurance documents...")
                response = talk_to_agent(agent, query, session_id)
                print(f"\nAnswer: {response}")
            except KeyboardInterrupt:
                print("\n\nThank you for using HDFC Life Insurance Assistant.")
                break
            except Exception as e:
                print(f"\nError: {str(e)}")
                print("Please try again or contact support if the issue persists.")
    except Exception as e:
        print(f"\nCritical error: {str(e)}")
        print("Please check your configuration and try again.")


def print_help():
    print("\nHELP - HDFC Life Insurance Assistant")
    print("-" * 50)
    print("This assistant can help you understand your HDFC Life insurance policies:")

    print("\nWhat you can ask about:")
    print("- Coverage details and sum assured")
    print("- Premium amounts and payment terms")
    print("- Policy benefits and features")
    print("- Claim procedures and requirements")
    print("- Maturity benefits")
    print("- Surrender values")
    print("- Exclusions and limitations")

    print("\nCommands:")
    print("- 'help'  Show this help message")
    print("- 'status'  Show system status")
    print("- 'exit'  Quit the application")

    print("\nExample questions:")
    print("- What are the benefits of Click 2 Protect?")
    print("- How do I claim my insurance?")
    print("- What is the premium for Click 2 Protect Supreme?")
    print("- What are the exclusions in my policy?")
    print("- Tell me about maturity benefits")


def print_status(vector_store):
    print("\nSYSTEM STATUS")
    print("-" * 30)
    print(f"Project ID: {config.PROJECT_ID}")
    print(f"Documents loaded: {len(vector_store.documents) if vector_store else 0}")
    print(f"Vector store: {'Ready' if vector_store and vector_store.documents else 'Empty'}")
    print(f"Model: Gemini 1.5 Pro")
    print(f"Region: {config.REGION}")


if __name__ == "__main__":
    main()
