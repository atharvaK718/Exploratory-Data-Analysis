import uuid
import time
from typing import Optional, Dict, Any, List
from datetime import datetime
import vertexai
from vertexai.preview import reasoning_engines
from vertexai.preview.generative_models import GenerativeModel
from google.cloud import storage
import json
from config import (
    PROJECT_ID, REGION, GEMINI_MODEL_NAME,
    AGENT_DISPLAY_NAME, AGENT_DESCRIPTION
)
from rag_engine import VertexRAGEngine
from vertex_vector_search import VertexVectorSearch


class VertexAgentEngine:
    """Agent using Vertex AI with optional RAG and Vector Search."""
    def __init__(self, rag_engine: Optional[VertexRAGEngine] = None,
                 vector_search: Optional[VertexVectorSearch] = None):
        self.project_id = PROJECT_ID
        self.region = REGION
        self.agent_name = f"hdfc-insurance-agent-{int(time.time())}"
        self.bucket_name = f"{PROJECT_ID}-agent-sessions"

        vertexai.init(project=PROJECT_ID, location=REGION)

        self.rag_engine = rag_engine
        self.vector_search = vector_search

        self.reasoning_engine = None
        self.agent_app = None
        self.storage_client = storage.Client(project=PROJECT_ID)

        self.active_sessions = {}
        print(f"Initialized VertexAgentEngine for project: {PROJECT_ID}")

    def setup_agent_storage(self) -> bool:
        try:
            bucket = self.storage_client.bucket(self.bucket_name)
            if not bucket.exists():
                bucket = self.storage_client.create_bucket(
                    self.bucket_name,
                    location=self.region
                )
                print(f"Created agent storage bucket: {self.bucket_name}")
            else:
                print(f"Using existing agent bucket: {self.bucket_name}")
            return True
        except Exception as e:
            print(f"Error setting up agent storage: {e}")
            return False

    def create_reasoning_engine_app(self) -> str:
        app_code = '''
import vertexai
from vertexai.preview import rag
from vertexai.preview.generative_models import GenerativeModel
from typing import Dict, Any, List
from datetime import datetime

class HDFCInsuranceAgent:
    """HDFC Life Insurance specialist agent with RAG capabilities."""
    def __init__(self, project_id: str, location: str):
        vertexai.init(project=project_id, location=location)
        self.system_instruction = """You are an expert HDFC Life Insurance assistant with comprehensive knowledge of insurance products and policies.
Your specialties include:
- HDFC Life Click 2 Protect series (Life, Supreme, Ultimate, Elite Plus)
- HDFC Life TROP (Term Return of Premium)
- HDFC Life Quick Protect
- Other HDFC Life insurance products
Core responsibilities:
1. Provide accurate information about policy features and benefits
2. Explain premium calculations and payment options
3. Guide customers through claims procedures
4. Clarify policy terms, conditions, and exclusions
5. Assist with maturity benefits and surrender value queries
6. Compare different HDFC Life products
Guidelines:
- Always base answers on the provided document context
- Use simple, customer-friendly language
- Be specific about coverage amounts, procedures, and timelines
- Cite source documents when providing detailed information
- If information is not available, clearly state this and suggest contacting HDFC Life
- For financial calculations, show step-by-step breakdowns
- Always remind users this is informational assistance only
Remember: Encourage customers to verify important details directly with HDFC Life for official confirmation."""
    def query(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        try:
            user_question = input_data.get('question', '')
            session_id = input_data.get('session_id', 'default')
            if not user_question:
                return {
                    'response': 'Please provide a question about HDFC Life insurance.',
                    'session_id': session_id,
                    'status': 'error'
                }

            enhanced_query = f"""As an HDFC Life Insurance expert, please answer this customer question:
Customer Question: {user_question}
Please provide a detailed, helpful response based on HDFC Life insurance policy documents. Include:
1. Direct answer to the question
2. Relevant policy details and coverage information
3. Any important conditions or exclusions
4. Specific procedures if applicable
5. Suggestion to contact HDFC Life for official confirmation
Focus on HDFC Life products like Click 2 Protect, TROP, Quick Protect, and other relevant policies."""

            model = GenerativeModel(
                model_name="gemini-1.5-pro",
                system_instruction=self.system_instruction
            )
            response = model.generate_content(enhanced_query)
            return {
                'response': response.text if response and response.text else 'Unable to generate response',
                'session_id': session_id,
                'status': 'success',
                'timestamp': str(datetime.now()),
                'question': user_question
            }
        except Exception as e:
            return {
                'response': f'Error processing your question: {str(e)}. Please try again.',
                'session_id': session_id,
                'status': 'error'
            }
'''
        return app_code

    def create_reasoning_engine(self) -> bool:
        print("Creating Vertex AI Reasoning Engine (placeholder)")
        try:
            app_code = self.create_reasoning_engine_app()
            reasoning_engine_config = {
                "display_name": f"{AGENT_DISPLAY_NAME} - {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                "description": f"{AGENT_DESCRIPTION} with RAG capabilities for HDFC Life insurance",
                "spec": {
                    "python_version": "3.10",
                    "requirements": [
                        "google-cloud-aiplatform>=1.38.0",
                        "vertexai>=1.38.0"
                    ]
                }
            }
            self.reasoning_engine = {
                "name": self.agent_name,
                "config": reasoning_engine_config,
                "code": app_code,
                "created_at": datetime.now().isoformat()
            }
            print(f"Reasoning engine created: {self.agent_name}")
            return True
        except Exception as e:
            print(f"Error creating reasoning engine: {e}")
            return False

    def save_session_history(self, session_id: str, question: str, response: str, context_used: bool = False):
        try:
            timestamp = datetime.now().isoformat()
            session_data = self.load_session_history(session_id)

            conversation = {
                'timestamp': timestamp,
                'question': question,
                'response': response,
                'context_used': context_used,
                'agent': self.agent_name
            }
            session_data['conversations'].append(conversation)
            session_data['last_updated'] = timestamp
            session_data['total_questions'] = len(session_data['conversations'])

            bucket = self.storage_client.bucket(self.bucket_name)
            blob_name = f"sessions/{session_id}.json"
            blob = bucket.blob(blob_name)
            blob.upload_from_string(
                json.dumps(session_data, indent=2),
                content_type='application/json'
            )
        except Exception as e:
            print(f"Warning: Could not save session history: {e}")

    def load_session_history(self, session_id: str) -> Dict[str, Any]:
        try:
            bucket = self.storage_client.bucket(self.bucket_name)
            blob_name = f"sessions/{session_id}.json"
            blob = bucket.blob(blob_name)
            if blob.exists():
                content = blob.download_as_text()
                return json.loads(content)
            return {
                'session_id': session_id,
                'created_at': datetime.now().isoformat(),
                'conversations': [],
                'total_questions': 0,
                'last_updated': datetime.now().isoformat()
            }
        except Exception as e:
            print(f"Warning: Could not load session history: {e}")
            return {
                'session_id': session_id,
                'created_at': datetime.now().isoformat(),
                'conversations': [],
                'total_questions': 0,
                'last_updated': datetime.now().isoformat()
            }

    def generate_agent_response(self, question: str, session_id: str) -> str:
        try:
            context_used = False

            if self.rag_engine and self.rag_engine.generative_model:
                print("Using Vertex AI RAG Engine")
                response = self.rag_engine.generate_rag_response(question)
                context_used = True

            elif self.vector_search and self.vector_search.endpoint:
                print("Using Vector Search with Gemini")
                from vertex_vector_search import get_relevant_context_vector_search
                context = get_relevant_context_vector_search(self.vector_search, question)

                model = GenerativeModel(
                    model_name=GEMINI_MODEL_NAME,
                    system_instruction="You are an expert HDFC Life Insurance assistant. Use the provided context to answer questions accurately and helpfully."
                )
                if context:
                    prompt = f"""Based on the following HDFC Life insurance document context, please answer the customer's question:
CONTEXT:
{context}
CUSTOMER QUESTION: {question}
Please provide a comprehensive, helpful answer based on the context above."""
                    context_used = True
                else:
                    prompt = f"""Customer Question: {question}
Note: No specific document context was found. Please provide general guidance about HDFC Life insurance and suggest contacting HDFC Life directly for detailed information."""
                response_obj = model.generate_content(prompt)
                response = response_obj.text if response_obj and response_obj.text else "Unable to generate response"

            else:
                print("Using basic Gemini model")
                model = GenerativeModel(
                    model_name=GEMINI_MODEL_NAME,
                    system_instruction="You are an HDFC Life Insurance assistant. Provide helpful information about insurance products while encouraging customers to contact HDFC Life directly for official details."
                )
                prompt = f"""As an HDFC Life Insurance assistant, please answer this customer question:
{question}
Please provide helpful general information about HDFC Life insurance products and suggest contacting HDFC Life directly for specific policy details."""
                response_obj = model.generate_content(prompt)
                response = response_obj.text if response_obj and response_obj.text else "Unable to generate response"

            self.save_session_history(session_id, question, response, context_used)
            return response

        except Exception as e:
            error_msg = str(e)
            if "quota" in error_msg.lower() or "429" in error_msg:
                return "The API quota limit was reached. Please try again later or contact HDFC Life directly."
            return f"An error occurred: {error_msg}. Please try rephrasing your question or contact HDFC Life support."

    def get_session_stats(self, session_id: str) -> Dict[str, Any]:
        session_data = self.load_session_history(session_id)
        conversations = session_data.get('conversations', [])
        context_used_count = sum(1 for conv in conversations if conv.get('context_used', False))
        return {
            'session_id': session_id,
            'total_questions': len(conversations),
            'questions_with_context': context_used_count,
            'context_usage_rate': (context_used_count / len(conversations) * 100) if conversations else 0,
            'created_at': session_data.get('created_at'),
            'last_updated': session_data.get('last_updated'),
            'agent_name': self.agent_name
        }

    def get_agent_stats(self) -> Dict[str, Any]:
        try:
            stats = {
                'agent_name': self.agent_name,
                'project_id': self.project_id,
                'region': self.region,
                'rag_engine_available': bool(self.rag_engine),
                'vector_search_available': bool(self.vector_search),
                'reasoning_engine_created': bool(self.reasoning_engine),
                'storage_bucket': self.bucket_name
            }
            return stats
        except Exception as e:
            return {'error': str(e)}


def setup_vertex_agent_engine(rag_engine: Optional[VertexRAGEngine] = None,
                              vector_search: Optional[VertexVectorSearch] = None) -> Optional[VertexAgentEngine]:
    print("Setting up Vertex AI Agent Engine")
    try:
        agent_engine = VertexAgentEngine(rag_engine=rag_engine, vector_search=vector_search)

        if not agent_engine.setup_agent_storage():
            print("Failed to set up agent storage")
            return None

        if not agent_engine.create_reasoning_engine():
            print("Warning: Could not create reasoning engine, using fallback mode")

        capabilities = []
        if rag_engine:
            capabilities.append("Vertex AI RAG Engine")
        if vector_search:
            capabilities.append("Vector Search")
        if agent_engine.reasoning_engine:
            capabilities.append("Reasoning Engine")
        capabilities.append("Session Management")
        capabilities.append("Conversation History")

        print("Agent Capabilities:")
        for capability in capabilities:
            print(f"  {capability}")

        stats = agent_engine.get_agent_stats()
        print("Agent Statistics:")
        print(f" Agent name: {stats.get('agent_name')}")
        print(f" RAG Engine: {'Available' if stats.get('rag_engine_available') else 'Not available'}")
        print(f" Vector Search: {'Available' if stats.get('vector_search_available') else 'Not available'}")
        print(f" Storage bucket: {stats.get('storage_bucket')}")
        print("Vertex AI Agent Engine setup completed.")
        return agent_engine
    except Exception as e:
        print(f"Error setting up agent engine: {str(e)}")
        return None
