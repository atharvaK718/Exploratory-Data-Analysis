# Google Cloud Project Settings
PROJECT_ID = "mcdms-gcp-dev"
REGION = "us-central1"
LOCATION = f"{REGION}"

# Vertex AI Settings
VERTEX_AI_LOCATION = REGION

# Gemini Model Settings
GEMINI_MODEL_NAME = "gemini-1.5-pro"
GEMINI_MODEL_VERSION = "latest"

# Vector Store Settings
VECTOR_STORE_DISPLAY_NAME = "hdfc_insurance_documents"
EMBEDDING_MODEL = "text-embedding-004"
INDEX_DISPLAY_NAME = "hdfc-insurance-index"

# Agent Settings
AGENT_DISPLAY_NAME = "HDFC Life Insurance Assistant"
AGENT_DESCRIPTION = "AI assistant for answering questions about HDFC Life insurance documents"

# Data Processing Settings
CHUNK_SIZE = 1000
CHUNK_OVERLAP = 100
DATA_DIR = "data"

# Conversation Settings
MAX_TOKENS = 2048
TEMPERATURE = 0.7
