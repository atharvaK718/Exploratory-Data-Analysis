import os
import re
from typing import List, Dict, Any
from PyPDF2 import PdfReader  # type: ignore

# Import from config (absolute import)
from config import CHUNK_SIZE, CHUNK_OVERLAP


class DocumentChunk:
    """Simple document chunk class to replace LangChain Document."""
    def __init__(self, page_content: str, metadata: Dict[str, Any]):
        self.page_content = page_content
        self.metadata = metadata
        self.id = metadata.get('chunk_id', '')


def read_pdf_file(filepath: str) -> List[str]:
    """Read PDF file and extract text from all pages."""
    try:
        reader = PdfReader(filepath)
        pages = []
        for page_num, page in enumerate(reader.pages):
            text = page.extract_text()
            if text and text.strip():
                pages.append(text)
        return pages
    except Exception as e:
        print(f"Error reading PDF {filepath}: {str(e)}")
        return []


def read_txt_file(filepath: str) -> str:
    """Read TXT file and return content."""
    try:
        with open(filepath, 'r', encoding='utf-8') as file:
            return file.read()
    except Exception as e:
        print(f"Error reading TXT {filepath}: {str(e)}")
        return ""


def split_text_into_chunks(text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
    """Split text into overlapping chunks."""
    if len(text) <= chunk_size:
        return [text]

    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size

        # Try to break at sentence boundaries
        if end < len(text):
            search_start = max(start, end - 100)
            sentence_endings = ['.', '!', '?', '\n\n']
            for ending in sentence_endings:
                last_ending = text.rfind(ending, search_start, end)
                if last_ending > start:
                    end = last_ending + 1
                    break

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        # Move start position with overlap
        start = end - chunk_overlap
        if start >= len(text):
            break

    return chunks


def load_and_split_documents(data_dir: str = "data") -> List[DocumentChunk]:
    """Load and split documents from the specified directory."""
    documents = []
    if not os.path.exists(data_dir):
        print(f"Creating directory: {data_dir}")
        os.makedirs(data_dir)
        return []

    files = [f for f in os.listdir(data_dir) if f.endswith(('.pdf', '.txt'))]
    if not files:
        print(f"No PDF or TXT files found in {data_dir}")
        return []

    print(f"Found {len(files)} document(s) to process:")
    for file in files:
        print(f" - {file}")

    for filename in files:
        filepath = os.path.join(data_dir, filename)
        try:
            print(f"Processing: {filename}")
            if filename.endswith(".pdf"):
                pages = read_pdf_file(filepath)
                if not pages:
                    print(f" No text extracted from {filename}")
                    continue

                for page_num, page_text in enumerate(pages):
                    chunks = split_text_into_chunks(page_text, CHUNK_SIZE, CHUNK_OVERLAP)
                    for chunk_num, chunk_text in enumerate(chunks):
                        metadata = {
                            'source_file': filename,
                            'file_type': 'pdf',
                            'page_number': page_num + 1,
                            'chunk_number': chunk_num + 1,
                            'total_chunks': len(chunks),
                            'chunk_id': f"{filename}_page{page_num + 1}_chunk{chunk_num + 1}"
                        }
                        documents.append(DocumentChunk(chunk_text, metadata))

                total_chunks = sum(len(split_text_into_chunks(p, CHUNK_SIZE, CHUNK_OVERLAP)) for p in pages)
                print(f" Processed {len(pages)} page(s) into {total_chunks} chunks")

            elif filename.endswith(".txt"):
                text = read_txt_file(filepath)
                if not text.strip():
                    print(f" Empty or unreadable file: {filename}")
                    continue

                chunks = split_text_into_chunks(text, CHUNK_SIZE, CHUNK_OVERLAP)
                for chunk_num, chunk_text in enumerate(chunks):
                    metadata = {
                        'source_file': filename,
                        'file_type': 'txt',
                        'chunk_number': chunk_num + 1,
                        'total_chunks': len(chunks),
                        'chunk_id': f"{filename}_chunk{chunk_num + 1}"
                    }
                    documents.append(DocumentChunk(chunk_text, metadata))

                print(f" Processed into {len(chunks)} chunks")

        except Exception as e:
            print(f" Error processing {filename}: {str(e)}")
            continue
    print(f"Total document chunks created: {len(documents)}")
    return documents
