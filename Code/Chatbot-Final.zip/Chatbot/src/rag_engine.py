import time
from typing import Optional, Dict, Any, List
from datetime import datetime
from pathlib import Path

import vertexai
from vertexai.preview import rag
from vertexai.preview.generative_models import GenerativeModel

from google.cloud import storage
import json

from config import (
    PROJECT_ID, REGION, GEMINI_MODEL_NAME,
    AGENT_DISPLAY_NAME, AGENT_DESCRIPTION
)

RAG_CORPUS_DISPLAY_NAME = "hdfc-insurance-corpus"


class VertexRAGEngine:
    """Vertex AI RAG Engine for HDFC Life Insurance document retrieval and generation."""
    def __init__(self):
        self.project_id = PROJECT_ID
        self.region = REGION
        self.rag_corpus = None
        self.generative_model = None

        vertexai.init(project=PROJECT_ID, location=REGION)
        print(f"Initialized VertexRAGEngine for project: {PROJECT_ID}")

    def get_or_create_corpus(self) -> bool:
        """Return existing corpus by display_name or create a new one."""
        try:
            corpora = rag.list_corpora()
            for c in corpora:
                if getattr(c, "display_name", "") == RAG_CORPUS_DISPLAY_NAME:
                    self.rag_corpus = c
                    print(f"Using existing RAG corpus: {c.name}")
                    return True
        except Exception as e:
            print(f"Could not list corpora: {e}")

        try:
            self.rag_corpus = rag.create_corpus(
                display_name=RAG_CORPUS_DISPLAY_NAME
            )
            print(f"Created RAG corpus: {self.rag_corpus.name}")
            return True
        except Exception as e:
            print(f"Error creating RAG corpus: {e}")
            return False

    def ensure_corpus_has_files(self, data_dir: str = "data") -> bool:
        """Upload local PDF/TXT files to the RAG corpus if not present."""
        if not self.rag_corpus:
            print("No RAG corpus available")
            return False

        try:
            existing_files = list(rag.list_files(self.rag_corpus.name))
            existing_display_names = {f.display_name for f in existing_files}
        except Exception as e:
            print(f"Could not list RAG files: {e}")
            existing_display_names = set()

        paths = []
        for ext in ("*.pdf", "*.txt"):
            paths.extend(Path(data_dir).glob(ext))

        if not paths:
            print(f"No local PDF/TXT files found in {data_dir}")
            return False

        uploaded = 0
        for p in paths:
            if p.name in existing_display_names:
                continue
            try:
                rag.upload_file(
                    corpus_name=self.rag_corpus.name,
                    path=str(p),
                    display_name=p.name,
                    description=f"Uploaded from {data_dir}"
                )
                uploaded += 1
                print(f"Uploaded to RAG: {p.name}")
            except Exception as e:
                print(f"Skipped {p.name}: {e}")

        if uploaded == 0 and existing_display_names:
            print("RAG corpus already has these files, nothing to upload.")
        else:
            print(f"RAG upload complete. New files uploaded: {uploaded}")
        return True
    def create_generative_model(self) -> bool:
        """Create a generative model for RAG responses."""
        print("Creating generative model")
        try:
            self.generative_model = GenerativeModel(
                model_name=GEMINI_MODEL_NAME,
                system_instruction="""You are an expert HDFC Life Insurance assistant with access to comprehensive policy documents.
Your specialties include:
- HDFC Life Click 2 Protect series (Life, Supreme, Ultimate, Elite Plus)
- HDFC Life TROP (Term Return of Premium)
- HDFC Life Quick Protect
- Other HDFC Life insurance products
Core responsibilities:
1. Provide accurate information about policy features and benefits
2. Explain premium calculations and payment options
3. Guide customers through claims procedures
4. Clarify policy terms, conditions, and exclusions
5. Assist with maturity benefits and surrender value queries
6. Compare different HDFC Life products
Guidelines:
- Always base answers on HDFC Life insurance policy documents
- Use simple, customer-friendly language
- Be specific about coverage amounts, procedures, and timelines
- Cite source documents when providing detailed information
- If information is not available, clearly state this and suggest contacting HDFC Life
- For financial calculations, show step-by-step breakdowns
- Always remind users this is informational assistance only
Remember: Encourage customers to verify important details directly with HDFC Life for official confirmation."""
            )
            print("Created generative model")
            return True
        except Exception as e:
            print(f"Error creating generative model: {e}")
            return False

    def generate_rag_response(self, question: str) -> str:
        """Generate a response using the RAG-enabled generative model."""
        if not self.generative_model:
            return "RAG engine not properly initialized. Please contact support."
        try:
            context = ""
            if self.rag_corpus:
                try:
                    retrieved_docs = rag.retrieve(
                        corpus=self.rag_corpus,
                        query=question,
                        max_results=5
                    )
                    if retrieved_docs:
                        context = "\n\n".join([doc.text for doc in retrieved_docs])
                        print(f"Retrieved {len(retrieved_docs)} relevant documents from RAG corpus")
                    else:
                        print("No relevant documents found in RAG corpus")
                except Exception as e:
                    print(f"Could not retrieve from RAG corpus: {e}")

            if context:
                enhanced_question = f"""Based on the following HDFC Life insurance document context, please answer the customer's question:
CONTEXT:
{context}
CUSTOMER QUESTION: {question}
Please provide a detailed, helpful response based on the context above. Include:
1. Direct answer to the question
2. Relevant policy details and coverage information
3. Any important conditions or exclusions
4. Specific procedures if applicable
5. Suggestion to contact HDFC Life for official confirmation
Focus on HDFC Life products like Click 2 Protect, TROP, Quick Protect, and other relevant policies."""
            else:
                enhanced_question = f"""As an HDFC Life Insurance expert, please answer this customer question:
Customer Question: {question}
Please provide a detailed, helpful response based on your knowledge of HDFC Life insurance policies. Include:
1. Direct answer to the question
2. Relevant policy details and coverage information
3. Any important conditions or exclusions
4. Specific procedures if applicable
5. Suggestion to contact HDFC Life for official confirmation
Focus on HDFC Life products like Click 2 Protect, TROP, Quick Protect, and other relevant policies."""

            response = self.generative_model.generate_content(enhanced_question)
            if response and response.text:
                return response.text
            return "Unable to generate a response. Please try rephrasing your question or contact HDFC Life directly."
        except Exception as e:
            error_msg = str(e)
            if "quota" in error_msg.lower() or "429" in error_msg:
                return "The API quota limit was reached. Please try again later or contact HDFC Life directly."
            return f"An error occurred: {error_msg}. Please try rephrasing your question or contact HDFC Life support."

    def get_rag_stats(self) -> Dict[str, Any]:
        try:
            stats = {
                'rag_corpus_display_name': RAG_CORPUS_DISPLAY_NAME,
                'rag_corpus_created': bool(self.rag_corpus),
                'generative_model_created': bool(self.generative_model),
                'project_id': self.project_id,
                'region': self.region
            }
            if self.rag_corpus:
                stats['rag_corpus_resource_name'] = self.rag_corpus.name
            return stats
        except Exception as e:
            return {'error': str(e)}


def setup_vertex_rag_engine() -> Optional[VertexRAGEngine]:
    """Set up Vertex AI RAG Engine for HDFC Life insurance documents (idempotent)."""
    print("Setting up Vertex AI RAG Engine")
    try:
        rag_engine = VertexRAGEngine()

        if not rag_engine.get_or_create_corpus():
            print("Warning: Could not create or find RAG corpus. Continuing with model only.")

        if not rag_engine.create_generative_model():
            print("Failed to create generative model")
            return None

        if rag_engine.rag_corpus:
            rag_engine.ensure_corpus_has_files(data_dir="data")

        stats = rag_engine.get_rag_stats()
        print("RAG Engine Statistics:")
        print(f" Corpus display name: {stats.get('rag_corpus_display_name')}")
        print(f" Corpus created: {'Yes' if stats.get('rag_corpus_created') else 'No'}")
        print(f" Generative model: {'Yes' if stats.get('generative_model_created') else 'No'}")
        print(f" Project: {stats.get('project_id')}")
        print(f" Region: {stats.get('region')}")
        print("Vertex AI RAG Engine setup completed.")
        return rag_engine
    except Exception as e:
        print(f"Error setting up RAG engine: {str(e)}")
        return None
