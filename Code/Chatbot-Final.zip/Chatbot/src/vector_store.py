import os
import uuid
import time
from typing import List, Optional, Dict, Any
import vertexai
from vertexai.language_models import TextEmbeddingModel
from google.cloud import aiplatform
from google.cloud.aiplatform import MatchingEngineIndex, MatchingEngineIndexEndpoint

from config import (
    PROJECT_ID, REGION, VECTOR_STORE_DISPLAY_NAME,
    EMBEDDING_MODEL, DATA_DIR, INDEX_DISPLAY_NAME
)
from data_ingestion import load_and_split_documents, DocumentChunk


class VectorStore:
    """Vector store implementation using Vertex AI Matching Engine."""
    def __init__(self):
        self.index = None
        self.endpoint = None
        self.embeddings_model = None
        self.documents = {}

    def initialize_vertex_ai(self):
        vertexai.init(project=PROJECT_ID, location=REGION)
        aiplatform.init(project=PROJECT_ID, location=REGION)
        self.embeddings_model = TextEmbeddingModel.from_pretrained(EMBEDDING_MODEL)
        print(f"Initialized with embedding model: {EMBEDDING_MODEL}")

    def get_embeddings(self, texts: List[str]) -> List[List[float]]:
        try:
            batch_size = 5
            all_embeddings = []
            for i in range(0, len(texts), batch_size):
                batch = texts[i:i + batch_size]
                embeddings = self.embeddings_model.get_embeddings(batch)
                for embedding in embeddings:
                    all_embeddings.append(embedding.values)
                time.sleep(0.1)
            return all_embeddings
        except Exception as e:
            print(f"Error getting embeddings: {str(e)}")
            return []

    def create_index(self) -> Optional[MatchingEngineIndex]:
        try:
            existing_indexes = aiplatform.MatchingEngineIndex.list(
                filter=f'display_name="{INDEX_DISPLAY_NAME}"'
            )
            if existing_indexes:
                print(f"Using existing index: {INDEX_DISPLAY_NAME}")
                return existing_indexes[0]

            print(f"Creating new index: {INDEX_DISPLAY_NAME}")
            index = aiplatform.MatchingEngineIndex.create_tree_ah_index(
                display_name=INDEX_DISPLAY_NAME,
                contents_delta_uri=f"gs://{PROJECT_ID}-vector-data/initial",
                dimensions=768,
                approximate_neighbors_count=10,
                distance_measure_type="DOT_PRODUCT_DISTANCE",
                leaf_node_embedding_count=1000,
                leaf_nodes_to_search_percent=10,
                description="Vector index for insurance documents",
                labels={"use_case": "insurance_rag"},
                sync=True
            )
            print(f"Index created successfully: {index.resource_name}")
            return index
        except Exception as e:
            print(f"Error creating index: {str(e)}")
            return None

    def create_endpoint(self) -> Optional[MatchingEngineIndexEndpoint]:
        try:
            existing_endpoints = aiplatform.MatchingEngineIndexEndpoint.list(
                filter=f'display_name="{INDEX_DISPLAY_NAME}-endpoint"'
            )
            if existing_endpoints:
                print(f"Using existing endpoint: {INDEX_DISPLAY_NAME}-endpoint")
                return existing_endpoints[0]

            print(f"Creating new endpoint: {INDEX_DISPLAY_NAME}-endpoint")
            endpoint = aiplatform.MatchingEngineIndexEndpoint.create(
                display_name=f"{INDEX_DISPLAY_NAME}-endpoint",
                description="Endpoint for insurance documents vector search",
                network=f"projects/{PROJECT_ID}/global/networks/default",
                sync=True
            )
            print(f"Endpoint created successfully: {endpoint.resource_name}")
            return endpoint
        except Exception as e:
            print(f"Error creating endpoint: {str(e)}")
            return None


class SimpleVectorStore:
    """Simplified in-memory vector store for development."""
    def __init__(self):
        self.embeddings_model = None
        self.documents = []
        self.embeddings = []

    def initialize(self):
        vertexai.init(project=PROJECT_ID, location=REGION)
        self.embeddings_model = TextEmbeddingModel.from_pretrained(EMBEDDING_MODEL)
        print(f"Initialized simple vector store with {EMBEDDING_MODEL}")

    def add_documents(self, documents: List[DocumentChunk]) -> bool:
        try:
            print(f"Adding {len(documents)} documents to vector store...")
            texts = [doc.page_content for doc in documents]
            batch_size = 5
            all_embeddings = []
            for i in range(0, len(texts), batch_size):
                batch = texts[i:i + batch_size]
                print(f"Processing batch {i//batch_size + 1}/{(len(texts)-1)//batch_size + 1}")
                embeddings = self.embeddings_model.get_embeddings(batch)
                for embedding in embeddings:
                    all_embeddings.append(embedding.values)
                time.sleep(0.1)

            self.documents.extend(documents)
            self.embeddings.extend(all_embeddings)
            print(f"Successfully added {len(documents)} documents to vector store")
            return True
        except Exception as e:
            print(f"Error adding documents: {str(e)}")
            return False

    def similarity_search(self, query: str, k: int = 5) -> List[DocumentChunk]:
        try:
            if not self.documents:
                print("No documents in vector store")
                return []

            query_embeddings = self.embeddings_model.get_embeddings([query])
            query_vector = query_embeddings[0].values

            import numpy as np
            query_vec = np.array(query_vector)
            doc_vecs = np.array(self.embeddings)

            similarities = np.dot(doc_vecs, query_vec) / (
                np.linalg.norm(doc_vecs, axis=1) * np.linalg.norm(query_vec)
            )

            top_indices = np.argsort(similarities)[::-1][:k]
            results = []
            for idx in top_indices:
                doc = self.documents[idx]
                doc.similarity_score = float(similarities[idx])
                results.append(doc)

            print(f"Found {len(results)} similar documents")
            return results
        except Exception as e:
            print(f"Error in similarity search: {str(e)}")
            return []


def setup_vector_store() -> Optional[SimpleVectorStore]:
    """Set up the vector store and ingest data (in-memory)."""
    print("Setting up Vertex AI Vector Store")
    vector_store = SimpleVectorStore()
    vector_store.initialize()

    print(f"Processing documents from '{DATA_DIR}' directory...")
    documents = load_and_split_documents(DATA_DIR)
    if not documents:
        print(f"No documents found in '{DATA_DIR}' directory.")
        print("Add PDF or TXT files to the data directory.")
        return vector_store

    print(f"Loaded {len(documents)} document chunks")
    for i, doc in enumerate(documents[:3]):
        print(f"  Sample chunk {i+1}: {len(doc.page_content)} chars from {doc.metadata.get('source_file', 'unknown')}")

    success = vector_store.add_documents(documents)
    if success:
        print("Vector store setup completed successfully.")
    else:
        print("Vector store setup completed with warnings.")
    return vector_store


def get_relevant_context(vector_store: SimpleVectorStore, query: str, max_chunks: int = 3) -> str:
    """Get relevant context from vector store for a given query."""
    results = vector_store.similarity_search(query, k=max_chunks)
    if not results:
        return ""
    context_parts = []
    for i, result in enumerate(results, 1):
        source_file = result.metadata.get('source_file', 'Unknown')
        page_num = result.metadata.get('page_number', '')
        page_info = f" (Page {page_num})" if page_num else ""
        context_parts.append(
            f"Context {i} from {source_file}{page_info}:\n{result.page_content}\n"
        )
    return "\n".join(context_parts)
