import uuid
from typing import Optional, Dict, Any, List
import vertexai
from vertexai.generative_models import GenerativeModel, ChatSession

from config import (
    PROJECT_ID, REGION, GEMINI_MODEL_NAME,
    AGENT_DISPLAY_NAME, AGENT_DESCRIPTION,
    MAX_TOKENS, TEMPERATURE
)
from vector_store import get_relevant_context, SimpleVectorStore


class InsuranceAgent:
    """Insurance chatbot agent using Vertex AI Gemini."""
    def __init__(self, vector_store: SimpleVectorStore):
        self.vector_store = vector_store
        self.model = None
        self.chat_sessions: Dict[str, ChatSession] = {}

        vertexai.init(project=PROJECT_ID, location=REGION)

        generation_config = {
            "max_output_tokens": MAX_TOKENS,
            "temperature": TEMPERATURE,
            "top_p": 0.8,
            "top_k": 40
        }
        self.model = GenerativeModel(
            model_name=GEMINI_MODEL_NAME,
            generation_config=generation_config
        )

        self.system_prompt = f"""You are {AGENT_DESCRIPTION}.
Your role is to help users understand their insurance documents by:
1. Answering questions about policy details, coverage, terms, and conditions
2. Explaining insurance terminology in simple terms
3. Providing accurate information based on the uploaded documents
4. Being helpful, professional, and empathetic
Guidelines:
- Always base your answers on the provided document context
- If you don't find relevant information in the documents, clearly state this
- Use simple, clear language that non-experts can understand
- Be specific about policy numbers, dates, and coverage details when available
- If asked about something not in the documents, suggest contacting the insurance provider directly
- Cite the source document when providing specific information
Remember: You are an AI assistant, not a replacement for professional insurance advice."""

    def get_or_create_session(self, session_id: str) -> ChatSession:
        if session_id not in self.chat_sessions:
            self.chat_sessions[session_id] = self.model.start_chat(history=[])
        return self.chat_sessions[session_id]

    def generate_response(self, query: str, session_id: str) -> str:
        try:
            context = get_relevant_context(self.vector_store, query)

            if context:
                prompt = f"""{self.system_prompt}
Based on the following insurance document context, please answer the user's question:
CONTEXT:
{context}
USER QUESTION: {query}
Please provide a helpful, accurate answer based on the context above. If the context doesn't contain enough information to answer the question, please say so and suggest contacting the insurance provider directly."""
            else:
                prompt = f"""{self.system_prompt}
USER QUESTION: {query}
Note: No relevant context was found in the uploaded insurance documents. Please respond appropriately and suggest they contact their insurance provider for specific details not covered in the documents."""

            chat_session = self.get_or_create_session(session_id)
            response = chat_session.send_message(prompt)
            return response.text
        except Exception as e:
            error_msg = str(e)
            if "quota" in error_msg.lower():
                return "I apologize, but the API quota limit was reached. Please try again later or contact support."
            return f"An error occurred while processing your question: {error_msg}. Please try again or contact support if the issue persists."

    def get_session_history(self, session_id: str) -> List[str]:
        if session_id in self.chat_sessions:
            session = self.chat_sessions[session_id]
            try:
                return [turn.text for turn in session.history]
            except Exception:
                return []
        return []


def setup_agent(vector_store: SimpleVectorStore) -> Optional[InsuranceAgent]:
    print("Setting up Vertex AI Agent with Gemini")
    try:
        agent = InsuranceAgent(vector_store)
        print(f"Agent '{AGENT_DISPLAY_NAME}' initialized successfully with {GEMINI_MODEL_NAME}")
        return agent
    except Exception as e:
        print(f"Error setting up agent: {str(e)}")
        return None


def talk_to_agent(agent: InsuranceAgent, query: str, session_id: str) -> str:
    return agent.generate_response(query, session_id)
