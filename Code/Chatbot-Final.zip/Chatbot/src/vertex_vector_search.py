import os
import time
import json
from typing import List, Optional, Dict, Any
from datetime import datetime

import vertexai
from vertexai.language_models import TextEmbeddingModel
from google.cloud import aiplatform
from google.cloud.aiplatform import MatchingEngineIndex, MatchingEngineIndexEndpoint
from google.cloud import storage

from config import PROJECT_ID, REGION, EMBEDDING_MODEL, DATA_DIR, INDEX_DISPLAY_NAME
from data_ingestion import load_and_split_documents, DocumentChunk


class VertexVectorSearch:
    """Production-ready vector search using Vertex AI Matching Engine."""
    def __init__(self):
        self.project_id = PROJECT_ID
        self.region = REGION
        self.index_display_name = INDEX_DISPLAY_NAME
        self.endpoint_display_name = f"{INDEX_DISPLAY_NAME}-endpoint"
        self.bucket_name = f"{PROJECT_ID}-vector-search-data"

        vertexai.init(project=PROJECT_ID, location=REGION)
        aiplatform.init(project=PROJECT_ID, location=REGION)
        self.embeddings_model = TextEmbeddingModel.from_pretrained(EMBEDDING_MODEL)
        self.storage_client = storage.Client(project=PROJECT_ID)

        self.index: Optional[MatchingEngineIndex] = None
        self.endpoint: Optional[MatchingEngineIndexEndpoint] = None
        self.deployed_index_id: Optional[str] = None

        self.document_metadata: Dict[str, Any] = {}
        print(f"Initialized VertexVectorSearch for project: {PROJECT_ID}")

    def setup_storage_bucket(self) -> bool:
        """Create storage bucket for vector index data (idempotent)."""
        try:
            bucket = self.storage_client.bucket(self.bucket_name)
            if not bucket.exists():
                bucket = self.storage_client.create_bucket(
                    self.bucket_name,
                    location=self.region
                )
                lifecycle_rule = {
                    'action': {'type': 'Delete'},
                    'condition': {'age': 365}
                }
                bucket.lifecycle_rules = [lifecycle_rule]
                bucket.patch()
                print(f"Created storage bucket: {self.bucket_name}")
            else:
                print(f"Using existing bucket: {self.bucket_name}")
            return True
        except Exception as e:
            print(f"Error setting up storage bucket: {e}")
            return False

    def get_embeddings_batch(self, texts: List[str]) -> List[List[float]]:
        """Get embeddings with batching and simple retries."""
        batch_size = 5
        all_embeddings: List[List[float]] = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            print(f"Processing embeddings batch {i//batch_size + 1}/{(len(texts)-1)//batch_size + 1}")
            max_retries = 3
            for retry in range(max_retries):
                try:
                    embeddings = self.embeddings_model.get_embeddings(batch)
                    for embedding in embeddings:
                        all_embeddings.append(embedding.values)
                    break
                except Exception as e:
                    if retry == max_retries - 1:
                        raise e
                    print(f"Retry {retry + 1}/{max_retries} for embeddings batch")
                    time.sleep(2 ** retry)
            time.sleep(0.2)
        return all_embeddings
    def prepare_vector_data(self, documents: List[DocumentChunk]) -> str:
        """Prepare JSONL vector data and upload to GCS."""
        print(f"Preparing vector data for {len(documents)} documents")
        try:
            texts = [doc.page_content for doc in documents]
            embeddings = self.get_embeddings_batch(texts)
            if len(embeddings) != len(texts):
                raise ValueError("Embedding count mismatch")

            vector_data = []
            for doc, embedding in zip(documents, embeddings):
                doc_id = f"{doc.metadata['source_file']}_{doc.metadata['chunk_id']}".replace('.', '_').replace(' ', '_')
                self.document_metadata[doc_id] = {
                    'page_content': doc.page_content,
                    'metadata': doc.metadata
                }
                vector_entry = {
                    'id': doc_id,
                    'embedding': embedding,
                    'restricts': [
                        {'namespace': 'source_file', 'allow': [doc.metadata['source_file']]},
                        {'namespace': 'file_type', 'allow': [doc.metadata['file_type']]}
                    ]
                }
                vector_data.append(vector_entry)

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            blob_name = f"vector_data/embeddings_{timestamp}.jsonl"
            bucket = self.storage_client.bucket(self.bucket_name)
            blob = bucket.blob(blob_name)
            jsonl_content = '\n'.join(json.dumps(entry) for entry in vector_data)
            blob.upload_from_string(jsonl_content)

            metadata_blob_name = f"metadata/documents_{timestamp}.json"
            metadata_blob = bucket.blob(metadata_blob_name)
            metadata_blob.upload_from_string(json.dumps(self.document_metadata, indent=2))

            gcs_uri = f"gs://{self.bucket_name}/{blob_name}"
            print(f"Vector data uploaded to: {gcs_uri}")
            return gcs_uri
        except Exception as e:
            print(f"Error preparing vector data: {e}")
            return ""

    def get_or_create_index(self, gcs_uri: Optional[str] = None) -> Optional[MatchingEngineIndex]:
        """Return existing index by display_name or create a new one using gcs_uri."""
        try:
            existing = aiplatform.MatchingEngineIndex.list(
                filter=f'display_name="{self.index_display_name}"'
            )
            if existing:
                self.index = existing[0]
                print(f"Using existing index: {self.index_display_name}")
                return self.index
        except Exception as e:
            print(f"Could not list indexes: {e}")

        if not gcs_uri:
            print("No existing index and no gcs_uri provided (skipping creation).")
            return None

        print("Creating new vector index. This may take 20 to 30 minutes.")
        try:
            self.index = aiplatform.MatchingEngineIndex.create_tree_ah_index(
                display_name=self.index_display_name,
                contents_delta_uri=gcs_uri,
                dimensions=768,
                approximate_neighbors_count=10,
                distance_measure_type="DOT_PRODUCT_DISTANCE",
                leaf_node_embedding_count=100,
                leaf_nodes_to_search_percent=10,
                description="Vector index for HDFC Life insurance documents",
                labels={"environment": "production", "use_case": "insurance_rag"},
                sync=True
            )
            print(f"Vector index created: {self.index.resource_name}")
            return self.index
        except Exception as e:
            print(f"Error creating vector index: {e}")
            return None

    def get_or_create_endpoint(self) -> Optional[MatchingEngineIndexEndpoint]:
        """Return existing endpoint by display_name or create a new one."""
        try:
            existing = aiplatform.MatchingEngineIndexEndpoint.list(
                filter=f'display_name="{self.endpoint_display_name}"'
            )
            if existing:
                self.endpoint = existing[0]
                print(f"Using existing endpoint: {self.endpoint_display_name}")
                return self.endpoint
        except Exception as e:
            print(f"Could not list endpoints: {e}")

        print("Creating new index endpoint")
        try:
            self.endpoint = aiplatform.MatchingEngineIndexEndpoint.create(
                display_name=self.endpoint_display_name,
                description="Endpoint for HDFC Life insurance vector search",
                public_endpoint_enabled=True,
                labels={"environment": "production", "use_case": "insurance_rag"},
                sync=True
            )
            print(f"Index endpoint created: {self.endpoint.resource_name}")
            return self.endpoint
        except Exception as e:
            print(f"Error creating index endpoint: {e}")
            return None

    def ensure_deployed(self) -> bool:
        """Deploy index to endpoint if not already deployed; otherwise reuse."""
        if not self.index or not self.endpoint:
            print("Index or endpoint not initialized")
            return False

        try:
            if self.endpoint.deployed_indexes:
                self.deployed_index_id = self.endpoint.deployed_indexes[0].id
                print(f"Using existing deployment: {self.deployed_index_id}")
                return True
        except Exception as e:
            print(f"Could not read existing deployments: {e}")

        print("Deploying index to endpoint")
        try:
            self.deployed_index_id = f"deployed_index_{int(time.time())}"
            self.endpoint.deploy_index(
                index=self.index,
                deployed_index_id=self.deployed_index_id,
                display_name="HDFC Life Insurance Index",
                machine_type="n1-standard-16",
                min_replica_count=1,
                max_replica_count=1,
                sync=True
            )
            print(f"Index deployed: {self.deployed_index_id}")
            return True
        except Exception as e:
            print(f"Error deploying index: {e}")
            return False

    def load_document_metadata(self):
        """Load latest document metadata from storage."""
        try:
            bucket = self.storage_client.bucket(self.bucket_name)
            metadata_blobs = [blob for blob in bucket.list_blobs(prefix="metadata/")]
            if not metadata_blobs:
                print("No metadata files found")
                return
            latest_blob = max(metadata_blobs, key=lambda x: x.time_created)
            metadata_content = latest_blob.download_as_text()
            self.document_metadata = json.loads(metadata_content)
            print(f"Loaded metadata for {len(self.document_metadata)} documents")
        except Exception as e:
            print(f"Error loading document metadata: {e}")

    def similarity_search(self, query: str, num_neighbors: int = 5) -> List[Dict[str, Any]]:
        """Search for similar documents using vector search."""
        if not self.endpoint or not self.deployed_index_id:
            print("Vector search not properly initialized")
            return []
        try:
            query_embeddings = self.embeddings_model.get_embeddings([query])
            query_vector = query_embeddings[0].values

            response = self.endpoint.find_neighbors(
                deployed_index_id=self.deployed_index_id,
                queries=[query_vector],
                num_neighbors=num_neighbors
            )

            results = []
            if response and len(response) > 0 and len(response[0]) > 0:
                for neighbor in response[0]:
                    doc_id = neighbor.id
                    score = neighbor.distance
                    if doc_id in self.document_metadata:
                        doc_data = self.document_metadata[doc_id]
                        result = {
                            'id': doc_id,
                            'page_content': doc_data['page_content'],
                            'metadata': doc_data['metadata'],
                            'score': score
                        }
                        results.append(result)
                print(f"Vector search found {len(results)} relevant documents")
            return results
        except Exception as e:
            print(f"Error in vector search: {e}")
            return []

    def get_search_stats(self) -> Dict[str, Any]:
        try:
            stats = {
                'index_name': self.index_display_name if self.index else None,
                'endpoint_name': self.endpoint_display_name if self.endpoint else None,
                'documents_count': len(self.document_metadata),
                'index_created': bool(self.index),
                'endpoint_created': bool(self.endpoint),
                'index_deployed': bool(self.deployed_index_id),
                'bucket_name': self.bucket_name
            }
            return stats
        except Exception as e:
            print(f"Error getting search stats: {e}")
            return {}


def setup_vertex_vector_search() -> Optional[VertexVectorSearch]:
    """Set up Vertex AI Vector Search with document processing (idempotent)."""
    print("Setting up Vertex AI Vector Search")
    vvs = VertexVectorSearch()

    if not vvs.setup_storage_bucket():
        print("Failed to set up storage bucket")
        return None

    vvs.index = vvs.get_or_create_index(gcs_uri=None)
    vvs.endpoint = vvs.get_or_create_endpoint()

    if not vvs.index:
        print(f"Processing documents from '{DATA_DIR}' directory...")
        documents = load_and_split_documents(DATA_DIR)
        if not documents:
            print(f"No documents found in '{DATA_DIR}' directory.")
            return None

        gcs_uri = vvs.prepare_vector_data(documents)
        if not gcs_uri:
            print("Failed to prepare vector data")
            return None

        vvs.index = vvs.get_or_create_index(gcs_uri=gcs_uri)
        if not vvs.index:
            return None

    if not vvs.endpoint:
        vvs.endpoint = vvs.get_or_create_endpoint()
        if not vvs.endpoint:
            return None

    if not vvs.ensure_deployed():
        return None

    vvs.load_document_metadata()

    stats = vvs.get_search_stats()
    print("Vector Search Statistics:")
    print(f" Documents processed (metadata): {stats.get('documents_count', 0)}")
    print(f" Index created: {'Yes' if stats.get('index_created') else 'No'}")
    print(f" Endpoint ready: {'Yes' if stats.get('endpoint_created') else 'No'}")
    print(f" Index deployed: {'Yes' if stats.get('index_deployed') else 'No'}")
    print("Vertex AI Vector Search setup completed.")
    return vvs


def get_relevant_context_vector_search(vector_search: VertexVectorSearch, query: str, max_chunks: int = 3) -> str:
    """Get relevant context using Vertex AI Vector Search."""
    results = vector_search.similarity_search(query, num_neighbors=max_chunks)
    if not results:
        return ""
    context_parts = []
    for i, result in enumerate(results, 1):
        metadata = result['metadata']
        source_file = metadata.get('source_file', 'Unknown')
        page_num = metadata.get('page_number', '')
        page_info = f" (Page {page_num})" if page_num else ""
        similarity = result.get('score', 0)
        context_parts.append(
            f"Context {i} from {source_file}{page_info} (relevance: {similarity:.3f}):\n{result['page_content']}\n"
        )
    return "\n".join(context_parts)
