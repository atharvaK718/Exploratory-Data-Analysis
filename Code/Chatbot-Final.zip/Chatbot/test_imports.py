import sys
from pathlib import Path
# Add src directory to Python path
current_dir = Path(__file__).parent
src_dir = current_dir / "src"
sys.path.insert(0, str(src_dir))

def test_imports():
    print(" Testing Python standard library imports...")
    try:
        import os
        import uuid
        import time
        from typing import List, Optional, Dict, Any
        print(" Standard library imports OK")
    except Exception as e:
        print(f" Standard library import error: {e}")
        return False
    
    print("\n Testing Google Cloud imports...")
    try:
        import vertexai
        from vertexai.language_models import TextEmbeddingModel
        from vertexai.generative_models import GenerativeModel, ChatSession
        from google.cloud import aiplatform
        import google.auth
        print(" Google Cloud imports OK")
    except Exception as e:
        print(f" Google Cloud import error: {e}")
        print(" Make sure you installed requirements: pip install -r requirements.txt")
        return False
    
    print("\n Testing other dependencies...")
    try:
        from PyPDF2 import PdfReader
        import numpy as np
        print(" Other dependencies OK")
    except Exception as e:
        print(f" Dependency import error: {e}")
        print(" Make sure you installed requirements: pip install -r requirements.txt")
        return False
    
    print("\n Testing local config import...")
    try:
        import config
        print(f" Config imported OK - Project: {config.PROJECT_ID}")
        
        if config.PROJECT_ID in ["your-gcp-project-id", "mcdms-gcp-dev"]:
            print("  Warning: Please update PROJECT_ID in src/config.py")
        
    except Exception as e:
        print(f" Config import error: {e}")
        return False
    
    print("\n Testing local module imports...")
    try:
        from data_ingestion import DocumentChunk, load_and_split_documents
        print(" data_ingestion imported OK")
    except Exception as e:
        print(f" data_ingestion import error: {e}")
        return False
    
    try:
        from vector_store import SimpleVectorStore, setup_vector_store
        print(" vector_store imported OK")
    except Exception as e:
        print(f" vector_store import error: {e}")
        return False
    
    try:
        from vertex_agent import InsuranceAgent, setup_agent
        print(" vertex_agent imported OK")
    except Exception as e:
        print(f" vertex_agent import error: {e}")
        return False
    
    print("\n Testing Google Cloud authentication...")
    try:
        credentials, project = google.auth.default()
        if credentials and project:
            print(f" Authentication OK - Project: {project}")
        else:
            print("  Authentication not configured properly")
            print(" Run: gcloud auth application-default login")
    except Exception as e:
        print(f"  Authentication issue: {e}")
        print(" Run: gcloud auth application-default login")
    
    return True

def test_data_directory():
    print("\n Testing data directory...")
    
    data_dir = Path("data")
    if not data_dir.exists():
        print(" Data directory doesn't exist - creating it...")
        data_dir.mkdir(exist_ok=True)
        print(" Created data/ directory")
        print(" Add your PDF/TXT insurance documents to data/ folder")
        return False
    
    # Check for files
    pdf_files = list(data_dir.glob("*.pdf"))
    txt_files = list(data_dir.glob("*.txt"))
    
    if not pdf_files and not txt_files:
        print("  No PDF or TXT files found in data/ directory")
        print(" Add your insurance documents to data/ folder")
        return False
    
    print(f" Found {len(pdf_files)} PDF file(s) and {len(txt_files)} TXT file(s)")
    for file in pdf_files + txt_files:
        print(f"   - {file.name}")
    
    return True

def main():
    """Run all import tests."""
    print(" Import and Setup Test")
    print("=" * 50)
    
    # Test imports
    if not test_imports():
        print("\n Import tests failed!")
        print("\nTo fix:")
        print("1. Install requirements: pip install -r requirements.txt")
        print("2. Make sure you're in the right directory")
        return
    
    # Test data directory
    has_data = test_data_directory()
    
    print("\n" + "=" * 50)
    print(" TEST SUMMARY")
    print("=" * 50)
    print(" All imports working correctly")
    
    if has_data:
        print(" Data directory ready with documents")
        print("\n Everything looks good! You can now run:")
        print("   local_main.py to run locally")
        print("   vertex_cloud_main.py to first deploy on cloud and then run")
        print("   deployed_quick_run.py if already deployed and run directly")
    else:
        print("  Data directory needs documents")
        print("\n Next steps:")
        print("1. Add PDF/TXT files to data/ folder")
        print("2. Update PROJECT_ID in src/config.py if needed")
        print("3. Run: python main.py")

if __name__ == "__main__":
    main()