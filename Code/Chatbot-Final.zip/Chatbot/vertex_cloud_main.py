import sys
import uuid
import json
import time
from datetime import datetime
from pathlib import Path

current_dir = Path(__file__).parent
src_dir = current_dir / "src"
sys.path.insert(0, str(src_dir))

import config
from vertex_vector_search import setup_vertex_vector_search
from rag_engine import setup_vertex_rag_engine
from agent_engine import setup_vertex_agent_engine


def check_vertex_prerequisites():
    """Check if Vertex AI deployment prerequisites are met."""
    issues = []
    if config.PROJECT_ID == "your-gcp-project-id":
        issues.append("Update PROJECT_ID in src/config.py")

    try:
        import google.auth
        credentials, project = google.auth.default()
        if not project:
            issues.append("Google Cloud credentials not found. Run 'gcloud auth application-default login'")
    except Exception:
        issues.append("Google Cloud authentication issue. Run 'gcloud auth application-default login'")
    return issues


def enable_vertex_apis():
    """Enable required Vertex AI APIs (best-effort)."""
    print("Enabling Vertex AI APIs")
    apis = [
        "aiplatform.googleapis.com",
        "storage.googleapis.com",
        "compute.googleapis.com"
    ]
    for api in apis:
        try:
            import subprocess
            result = subprocess.run([
                "gcloud", "services", "enable", api,
                f"--project={config.PROJECT_ID}"
            ], capture_output=True, text=True, timeout=30)
            if result.returncode == 0:
                print(f"Enabled {api}")
            else:
                print(f"{api} may already be enabled: {result.stderr}")
        except Exception as e:
            print(f"Could not enable {api}: {e}")


def choose_deployment_mode():
    """Let user choose between Vector Search and RAG Engine."""
    # print("VERTEX AI DEPLOYMENT OPTIONS")
    # print("=" * 50)
    # print("1. Vector Search Mode")
    # print("   - Uses Vertex AI Matching Engine")
    # print("   - For large document collections and custom similarity search")
    # print("   - Setup time: about 20–30 minutes on first index build")
    # print("2. RAG Engine Mode")
    # print("   - Uses Vertex AI RAG Engine")
    # print("   - For intelligent Q&A with managed infrastructure")
    # print("   - Setup time: about 5–10 minutes")
    # print("3. Hybrid Mode")
    # print("   - Uses both Vector Search and RAG Engine")
    # print("   - Setup time: about 30–40 minutes")
    # while True:
    #     choice = input("Enter your choice (1, 2, or 3): ").strip()
    #     if choice in ['1', '2', '3']:
    #         return int(choice)
    #     print("Enter 1, 2, or 3")
    
    while True:
        choice = 3



def deploy_vector_search_mode():
    """Deploy using Vertex AI Vector Search."""
    print("DEPLOYING VECTOR SEARCH MODE")
    print("=" * 50)
    print("Note: Vector index creation can take 20–30 minutes on first run")
    print("Monitor progress at:")
    print(f"  https://console.cloud.google.com/vertex-ai/matching-engine/indexes?project={config.PROJECT_ID}")

    proceed = input("Proceed with Vector Search deployment? (y/N): ").strip().lower()
    if proceed != 'y':
        return None, None

    vector_search = setup_vertex_vector_search()
    if not vector_search:
        print("Vector Search setup failed")
        return None, None

    agent_engine = setup_vertex_agent_engine(vector_search=vector_search)
    return vector_search, agent_engine


def deploy_rag_engine_mode():
    """Deploy using Vertex AI RAG Engine."""
    print("DEPLOYING RAG ENGINE MODE")
    print("=" * 40)
    print("Note: RAG setup takes about 5–10 minutes")
    print("Monitor progress at:")
    print(f"  https://console.cloud.google.com/vertex-ai/generative/rag?project={config.PROJECT_ID}")

    rag_engine = setup_vertex_rag_engine()
    if not rag_engine:
        print("RAG Engine setup failed")
        return None, None

    agent_engine = setup_vertex_agent_engine(rag_engine=rag_engine)
    return rag_engine, agent_engine


def deploy_hybrid_mode():
    """Deploy using both Vector Search and RAG Engine."""
    print("DEPLOYING HYBRID MODE")
    print("=" * 40)
    print("Note: Hybrid setup takes about 30–40 minutes")
    proceed = input("Proceed with Hybrid deployment? (y/N): ").strip().lower()
    if proceed != 'y':
        return None, None, None

    print("Setting up Vector Search")
    vector_search = setup_vertex_vector_search()
    if not vector_search:
        print("Vector Search setup failed")
        return None, None, None

    print("Setting up RAG Engine")
    rag_engine = setup_vertex_rag_engine()
    if not rag_engine:
        print("RAG Engine setup failed. Continuing with Vector Search only.")
        rag_engine = None

    print("Setting up Agent Engine")
    agent_engine = setup_vertex_agent_engine(
        rag_engine=rag_engine,
        vector_search=vector_search
    )
    return vector_search, rag_engine, agent_engine


def run_vertex_chatbot(agent_engine, deployment_mode="Unknown"):
    """Run the Vertex AI powered chatbot."""
    print("HDFC LIFE INSURANCE ASSISTANT ")
    print("=" * 70)
    print(f"Deployment: {deployment_mode}")
    print(f"Project: {config.PROJECT_ID}")
    print(f"Region: {config.REGION}")
    print(f"Model: {config.GEMINI_MODEL_NAME}")

    stats = agent_engine.get_agent_stats()
    print("Agent Capabilities:")
    if stats.get('rag_engine_available'):
        print("  Vertex AI RAG Engine")
    if stats.get('vector_search_available'):
        print("  Vector Search")
    print("  Session Management")
    print("  Conversation History")

    print("=" * 70)
    print("Ask questions about your HDFC Life insurance policies.")
    print("Commands: 'help', 'stats', 'clear', 'exit'")
    print("=" * 70)

    session_id = str(uuid.uuid4())
    session_start = datetime.now()
    print(f"Session: {session_id[:8]}...")
    print(f"Started: {session_start.strftime('%Y-%m-%d %H:%M')}")

    while True:
        try:
            query = input("\nYour question: ").strip()
            if query.lower() == 'exit':
                print("Thank you for using HDFC Life Insurance Assistant")
                print(f"Session duration: {datetime.now() - session_start}")
                print("Conversation saved in Vertex AI.")
                break
            elif query.lower() == 'help':
                print_vertex_help(deployment_mode)
                continue
            elif query.lower() == 'stats':
                print_session_stats(agent_engine, session_id)
                continue
            elif query.lower() == 'clear':
                session_id = str(uuid.uuid4())
                session_start = datetime.now()
                print(f"Started new session: {session_id[:8]}...")
                continue
            elif not query:
                continue

            print("Analyzing your question...")
            start_time = time.time()
            response = agent_engine.generate_agent_response(query, session_id)
            response_time = time.time() - start_time
            print(f"Answer ({response_time:.1f}s): {response}")
        except KeyboardInterrupt:
            print("Thank you for using HDFC Life Insurance Assistant")
            print("Conversation saved in Vertex AI.")
            break
        except Exception as e:
            print(f"Error: {str(e)}")
            print("Try again or contact support.")


def print_vertex_help(deployment_mode):
    """Print help information for Vertex AI assistant."""
    print("HDFC LIFE VERTEX AI ASSISTANT - HELP")
    print("-" * 55)
    print(f"Deployment Mode: {deployment_mode}")
    print("Specialized in: HDFC Life Insurance Products")

    print("Products Covered:")
    print("  - Click 2 Protect (Life, Supreme, Ultimate, Elite Plus)")
    print("  - TROP (Term Return of Premium)")
    print("  - Quick Protect")
    print("  - Other HDFC Life insurance policies")

    print("What you can ask:")
    print("  - Policy features, benefits, and coverage details")
    print("  - Premium calculations and payment options")
    print("  - Sum assured and maturity benefits")
    print("  - Claims procedures and required documentation")
    print("  - Policy terms, conditions, and exclusions")
    print("  - Surrender values and loan options")
    print("  - Product comparisons and recommendations")

    print("Commands:")
    print("  - 'help'  Show this help information")
    print("  - 'stats' Display session statistics")
    print("  - 'clear' Start new conversation session")
    print("  - 'exit'  Quit the assistant")

    print("Example questions:")
    print("  - What is the coverage in Click 2 Protect Supreme?")
    print("  - How do I calculate premium for 50 lakh coverage?")
    print("  - What are the tax benefits under TROP policy?")
    print("  - Which policy is better for a 30-year-old?")
    print("  - How to file a death claim with HDFC Life?")


def print_session_stats(agent_engine, session_id):
    """Print session statistics."""
    stats = agent_engine.get_session_stats(session_id)
    print("SESSION STATISTICS")
    print("-" * 35)
    print(f"Session ID: {session_id[:8]}...")
    print(f"Total questions: {stats.get('total_questions', 0)}")
    print(f"Questions with context: {stats.get('questions_with_context', 0)}")
    print(f"Context usage rate: {stats.get('context_usage_rate', 0):.1f}%")
    print(f"Agent: {stats.get('agent_name', 'Unknown')}")
    if stats.get('created_at'):
        print(f"Session started: {stats['created_at']}")
    if stats.get('last_updated'):
        print(f"Last activity: {stats['last_updated']}")


def main():
    """Main Vertex AI deployment and execution function."""
    print("HDFC Life Insurance Assistant - Vertex AI Cloud Deployment")
    print("=" * 70)

    issues = check_vertex_prerequisites()
    if issues:
        print("Setup issues found:")
        for issue in issues:
            print(f" - {issue}")
        return

    enable_vertex_apis()
    mode = choose_deployment_mode()

    agent_engine = None
    deployment_name = ""

    if mode == 1:
        vector_search, agent_engine = deploy_vector_search_mode()
        deployment_name = "Vector Search Mode"
    elif mode == 2:
        rag_engine, agent_engine = deploy_rag_engine_mode()
        deployment_name = "RAG Engine Mode"
    elif mode == 3:
        vector_search, rag_engine, agent_engine = deploy_hybrid_mode()
        deployment_name = "Hybrid Mode"

    if agent_engine:
        print("Deployment completed")
        print(f"Mode: {deployment_name}")
        print(f"Project: {config.PROJECT_ID}")

        deployment_info = {
            'mode': mode,
            'deployment_name': deployment_name,
            'project_id': config.PROJECT_ID,
            'timestamp': datetime.now().isoformat()
        }
        with open('deployment_info.json', 'w') as f:
            json.dump(deployment_info, f, indent=2)
        print("Use 'python quick_run.py' for quick access next time")

        run_vertex_chatbot(agent_engine, deployment_name)
    else:
        print("Deployment failed. Review errors and try again.")


if __name__ == "__main__":
    main()
